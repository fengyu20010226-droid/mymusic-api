// 聚合音乐 API 网关：把网易云、QQ 音乐、酷狗三个上游服务挂在一台机器上。
// 路由约定（前端直接把这些前缀当成 VITE_*_API_BASE）：
//   /netease/*  -> NeteaseCloudMusicApi
//   /kugou/*    -> KuGouMusicApi
//   /qq/*       -> qq-music-api（Web 标准 handler）
const http = require('node:http')
const { URL } = require('node:url')

const PORT = Number(process.env.PORT || 8000)
const NETEASE_PORT = Number(process.env.NETEASE_PORT || 3101)
const KUGOU_PORT = Number(process.env.KUGOU_PORT || 3102)
// QQ 登录会话要一个密钥才能跨请求保持；部署时可用环境变量固定，未设置就每次启动随机生成。
const QQ_SECRET = process.env.QQ_SESSION_SECRET || require('node:crypto').randomBytes(32).toString('hex')
// 只有在本机必须经 HTTP 代理才能出网时才需要设（例如沙箱里跑临时公网服务）；普通家用电脑留空。
const NETEASE_PROXY = process.env.NETEASE_PROXY || ''

const cors = (res, origin) => {
    res.setHeader('Access-Control-Allow-Origin', origin || '*')
    res.setHeader('Access-Control-Allow-Credentials', 'true')
    res.setHeader('Access-Control-Allow-Headers', 'content-type, authorization, x-qq-session, x-requested-with')
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
    res.setHeader('Access-Control-Expose-Headers', 'set-cookie')
}

const proxy = (req, res, targetPort, prefix) => {
    const path = req.url.startsWith(prefix) ? req.url.slice(prefix.length) || '/' : req.url
    const headers = { ...req.headers, host: `127.0.0.1:${targetPort}` }
    delete headers.origin

    const upstream = http.request({ host: '127.0.0.1', port: targetPort, path, method: req.method, headers }, upstreamRes => {
        // 上游自己也带 CORS 头，常见是 `Access-Control-Allow-Origin: *`；浏览器不允许 `*` 搭配
        // credentials，而网易云/酷狗登录要带 cookie。这里丢掉上游的这几个头，保留下面的 cors()。
        const outHeaders = { ...upstreamRes.headers }
        for (const key of Object.keys(outHeaders)) {
            if (key.toLowerCase().startsWith('access-control-')) delete outHeaders[key]
        }
        res.writeHead(upstreamRes.statusCode || 502, outHeaders)
        upstreamRes.pipe(res)
    })

    upstream.on('error', error => {
        console.error('[gateway] upstream error', prefix, error.message)
        if (!res.headersSent) res.writeHead(502, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ code: 502, message: `${prefix} upstream unavailable` }))
    })

    req.pipe(upstream)
}

const readBody = req => new Promise(resolve => {
    const chunks = []
    req.on('data', chunk => chunks.push(chunk))
    req.on('end', () => resolve(Buffer.concat(chunks)))
})

const main = async () => {
    // 1) 网易云：直接调包自带的 serveNcmApi，只监听回环。
    const { serveNcmApi } = require('@neteasecloudmusicapienhanced/api')
    await serveNcmApi({ port: NETEASE_PORT, host: '127.0.0.1', checkVersion: false })
    console.log(`[gateway] netease up on ${NETEASE_PORT}`)

    // 2) 酷狗：包内的 startService 读 PORT 环境变量，临时改一下再还原。
    process.env.platform = 'lite'
    const previousPort = process.env.PORT
    process.env.PORT = String(KUGOU_PORT)
    process.env.HOST = '127.0.0.1'
    const kugou = require('kugoumusicapi')
    const kugouApp = await kugou.startService()
    process.env.PORT = previousPort
    if (kugouApp?.service) {
        await new Promise(resolve => kugouApp.service.once('listening', resolve))
    }
    console.log(`[gateway] kugou up on ${KUGOU_PORT}`)

    // 3) QQ 音乐：包提供 Web 标准 handler，直接在前缀路由里调它。
    const { handleRequest } = require('@yakult-green-tea/qq-music-api/serverless')

    const server = http.createServer(async (req, res) => {
        const origin = req.headers.origin
        cors(res, origin)
        if (req.method === 'OPTIONS') {
            res.writeHead(204)
            res.end()
            return
        }

        if (req.url === '/healthz' || req.url === '/') {
            res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify({ ok: true, service: 'mymusic-api-gateway' }))
            return
        }

        if (req.url.startsWith('/netease')) {
            // 网易云包按每次请求的 proxy 查询参数走代理；已经自己带了 proxy 的就不覆盖。
            if (NETEASE_PROXY && !/[?&]proxy=/.test(req.url)) {
                req.url += `${req.url.includes('?') ? '&' : '?'}proxy=${encodeURIComponent(NETEASE_PROXY)}`
            }
            return proxy(req, res, NETEASE_PORT, '/netease')
        }
        if (req.url.startsWith('/kugou')) return proxy(req, res, KUGOU_PORT, '/kugou')

        if (req.url.startsWith('/qq')) {
            const target = new URL(req.url.slice(3) || '/', `http://127.0.0.1:${PORT}`)
            const headers = new Headers()
            for (const [key, value] of Object.entries(req.headers)) {
                if (key === 'origin' || key === 'host' || key === 'connection' || value === undefined) continue
                if (Array.isArray(value)) value.forEach(item => headers.append(key, item))
                else headers.set(key, String(value))
            }
            const body = req.method === 'GET' || req.method === 'HEAD' ? undefined : await readBody(req)
            try {
                const answer = await handleRequest(new Request(target, { method: req.method, headers, body }), {
                    QQ_SESSION_SECRET: QQ_SECRET,
                    QQ_SESSION_SECRET_PREVIOUS: process.env.QQ_SESSION_SECRET_PREVIOUS,
                })
                const out = {}
                answer.headers.forEach((value, key) => { out[key] = value })
                cors(res, origin)
                res.writeHead(answer.status, out)
                res.end(Buffer.from(await answer.arrayBuffer()))
            } catch (error) {
                console.error('[gateway] qq handler failed', error)
                if (!res.headersSent) res.writeHead(502, { 'content-type': 'application/json' })
                res.end(JSON.stringify({ code: 502, message: 'qq upstream error' }))
            }
            return
        }

        res.writeHead(404, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ code: 404, message: 'unknown route' }))
    })

    server.listen(PORT, '0.0.0.0', () => {
        console.log(`[gateway] listening on ${PORT}`)
        // 手机要填的是本机的局域网地址，127.0.0.1 只对电脑自己有效。把三条完整地址一并打印并写进
        // addresses.txt，省得在控制台里拼后缀。
        const addresses = []
        const nets = require('node:os').networkInterfaces()
        for (const name of Object.keys(nets)) {
            for (const net of nets[name] || []) {
                if (net.family === 'IPv4' && !net.internal) addresses.push(`http://${net.address}:${PORT}`)
            }
        }
        if (!addresses.length) addresses.push(`http://127.0.0.1:${PORT}`)
        const lines = ['聚合音乐 API 网关已启动（保持这个窗口开着）：']
        for (const base of addresses) {
            lines.push(`  网易云: ${base}/netease`, `  QQ音乐: ${base}/qq`, `  酷狗:   ${base}/kugou`)
        }
        console.log(lines.join('\n'))
        try {
            require('node:fs').writeFileSync(require('node:path').join(__dirname, 'addresses.txt'), `${lines.join('\n')}\n`)
        } catch (error) {
            console.warn('[gateway] addresses.txt not written', error.message)
        }
    })
}

main().catch(error => {
    console.error('[gateway] startup failed', error)
    process.exit(1)
})
